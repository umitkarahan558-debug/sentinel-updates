// ==============================================================================
// SENTINEL PRO v3.0 | CYBER-INDUSTRIAL COCKPIT ENGINE (JAVASCRIPT)
// ==============================================================================

let ws = null;
let reconnectTimer = null;
let streamInterval = null;
let streamActive = true;
let audioEnabled = true;
let currentTab = 'cockpit';
let currentLogFilter = 'ALL';
let profitChart = null;

let allLogs = [];
let lockedSlotsVIP = new Set();
let lockedSlotsBag = new Set();

// Web Audio API Synthesizer
let audioCtx = null;
function playTone(freq, type = 'sine', duration = 0.06, gainLevel = 0.1) {
    if (!audioEnabled) return;
    try {
        if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        if (audioCtx.state === 'suspended') audioCtx.resume();
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = type;
        osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
        gain.gain.setValueAtTime(gainLevel, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start();
        osc.stop(audioCtx.currentTime + duration);
    } catch (e) {
        // audio context blocked by browser policy until user gesture
    }
}

function playUiClick() { playTone(950, 'triangle', 0.04, 0.08); }
function playSuccessChirp() { 
    playTone(700, 'sine', 0.05, 0.08);
    setTimeout(() => playTone(1200, 'sine', 0.08, 0.09), 60);
}
function playAlertChirp() {
    playTone(350, 'sawtooth', 0.12, 0.12);
}

function toggleAudio() {
    audioEnabled = !audioEnabled;
    const btn = document.getElementById('btnAudio');
    const icon = document.getElementById('audioIcon');
    if (audioEnabled) {
        icon.innerText = "🔊";
        btn.className = "flex items-center justify-center w-9 h-9 rounded-xl border text-xs bg-slate-800/60 border-slate-700/60 text-cyan-400 transition";
        playTone(1000, 'sine', 0.05);
    } else {
        icon.innerText = "🔇";
        btn.className = "flex items-center justify-center w-9 h-9 rounded-xl border text-xs bg-slate-800/60 border-slate-700/60 text-slate-500 transition";
    }
}

function escapeHtml(str) {
    if (!str) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

function authFetch(url, options = {}) {
    options.credentials = 'include';
    if (!options.headers) options.headers = {};
    const token = sessionStorage.getItem('sentinel_auth_token');
    if (token) {
        if (options.headers instanceof Headers) {
            options.headers.set('Authorization', 'Bearer ' + token);
        } else {
            options.headers['Authorization'] = 'Bearer ' + token;
        }
    }
    return fetch(url, options);
}

// Global Logout Handler
async function handleLogout() {
    try {
        await authFetch('/api/auth/logout', { method: 'POST' });
    } catch (e) {
        console.warn('Logout request error:', e);
    }
    sessionStorage.removeItem('sentinel_auth_token');
    sessionStorage.removeItem('sentinel_user');
    window.location.reload();
}

// --- WebSocket Connection ---
function connectWS() {
    const token = sessionStorage.getItem('sentinel_auth_token') || '';
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws` + (token ? `?token=${encodeURIComponent(token)}` : '');

    ws = new WebSocket(wsUrl);

    ws.onopen = () => {
        console.log('[WS] Connected to Sentinel Core');
        updateConnectionBadge(true);
        if (reconnectTimer) {
            clearInterval(reconnectTimer);
            reconnectTimer = null;
        }
        loadTelegramConfig();
        playSuccessChirp();
    };

    ws.onmessage = (event) => {
        try {
            const data = JSON.parse(event.data);
            if (data.type === 'state_update') {
                renderState(data.payload);
            } else if (data.type === 'log') {
                appendLog(data.payload);
            }
        } catch (e) {
            console.error('[WS] Parse error:', e);
        }
    };

    ws.onclose = (ev) => {
        if (ev.code === 1008) {
            console.warn('[WS] Yetkilendirme hatası (1008): Oturum açılmamış.');
            updateConnectionBadge(false);
            const authModal = document.getElementById('authModal');
            if (authModal) authModal.classList.remove('hidden');
            switchAuthView('login');
            return;
        }
        console.warn('[WS] Disconnected. Reconnecting in 2s...');
        updateConnectionBadge(false);
        if (!reconnectTimer) {
            reconnectTimer = setInterval(connectWS, 2000);
        }
    };

    ws.onerror = (err) => {
        console.error('[WS] Error:', err);
        ws.close();
    };
}

function updateConnectionBadge(online) {
    const badge = document.getElementById('connBadge');
    const text = document.getElementById('connText');
    if (online) {
        badge.className = "flex items-center gap-2 px-3 py-1.5 rounded-xl border text-xs font-semibold bg-emerald-950/40 border-emerald-800/60 text-emerald-400";
        text.innerText = "ONLINE";
    } else {
        badge.className = "flex items-center gap-2 px-3 py-1.5 rounded-xl border text-xs font-semibold bg-rose-950/40 border-rose-800/60 text-rose-400";
        text.innerText = "OFFLINE";
    }
}

function formatTime(totalSec) {
    const m = Math.floor(totalSec / 60);
    const s = totalSec % 60;
    return `${m < 10 ? '0' + m : m}:${s < 10 ? '0' + s : s}`;
}

function formatUptime(sec) {
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = sec % 60;
    return `${h < 10 ? '0' + h : h}:${m < 10 ? '0' + m : m}:${s < 10 ? '0' + s : s}`;
}

// --- State Renderer ---
function renderState(data) {
    // 1. Master state & buttons
    const lblState = document.getElementById('lblState');
    const statusDot = document.getElementById('statusDot');
    const btnToggle = document.getElementById('btnMasterToggle');
    const btnIcon = document.getElementById('btnIcon');
    const btnText = document.getElementById('btnText');
    const btnStop = document.getElementById('btnMasterStop');
    const badgeRpr = document.getElementById('badgeRprAlert');
    const badgeInterrupted = document.getElementById('badgeUserInterrupted');

    if (data.state === 'RUNNING') {
        lblState.innerText = '● ÇALIŞIYOR';
        lblState.className = 'font-bold text-sm text-emerald-400 tracking-wide';
        statusDot.className = 'w-3.5 h-3.5 rounded-full bg-emerald-500 ring-4 ring-emerald-500/20';
        btnToggle.className = 'px-5 py-2 rounded-xl font-bold text-sm tracking-wide transition-all duration-200 shadow-lg flex items-center gap-2 bg-amber-600 hover:bg-amber-500 active:scale-95 text-white glow-amber';
        btnIcon.innerText = '⏸';
        btnText.innerText = 'DURAKLAT';
        if (btnStop) {
            btnStop.classList.remove('opacity-40', 'pointer-events-none');
            btnStop.title = 'Botu Durdur ve Başa Sıfırla (Çift 1/18)';
        }
    } else if (data.state === 'PAUSED') {
        lblState.innerText = '● DURAKLATILDI (BEKLEMEDE)';
        lblState.className = 'font-bold text-sm text-amber-400 tracking-wide';
        statusDot.className = 'w-3.5 h-3.5 rounded-full bg-amber-500 ring-4 ring-amber-500/20';
        btnToggle.className = 'px-5 py-2 rounded-xl font-bold text-sm tracking-wide transition-all duration-200 shadow-lg flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white glow-emerald';
        btnIcon.innerText = '▶';
        btnText.innerText = 'DEVAM ET';
        if (btnStop) {
            btnStop.classList.remove('opacity-40', 'pointer-events-none');
            btnStop.title = 'Botu Durdur ve Başa Sıfırla (Çift 1/18)';
        }
    } else {
        lblState.innerText = '● DURDURULDU (HAZIR)';
        lblState.className = 'font-bold text-sm text-slate-400 tracking-wide';
        statusDot.className = 'w-3.5 h-3.5 rounded-full bg-rose-500 ring-4 ring-rose-500/20';
        btnToggle.className = 'px-5 py-2 rounded-xl font-bold text-sm tracking-wide transition-all duration-200 shadow-lg flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white glow-emerald';
        btnIcon.innerText = '▶';
        btnText.innerText = 'BAŞLAT';
        if (btnStop) btnStop.classList.add('opacity-40');
    }

    if (data.license) {
        updateLicenseUI(data.license);
    }

    document.getElementById('lblAction').innerText = data.action_text || 'Hazır.';
    document.getElementById('lblUptime').innerText = formatUptime(data.uptime_sec || 0);

    // Vision Engine RPR Durumu
    if (data.rpr && data.rpr.needs_rpr) {
        badgeRpr.classList.remove('hidden');
    } else {
        badgeRpr.classList.add('hidden');
    }

    // Safety User Interrupted Durumu
    if (data.safety && data.safety.user_interrupted) {
        badgeInterrupted.classList.remove('hidden');
    } else {
        badgeInterrupted.classList.add('hidden');
    }

    // 2. Weapon Swap Card
    if (data.swap) {
        const mode = data.swap.trigger_mode || 'DURABILITY';
        const badgeSwap = document.getElementById('badgeSwap');
        const timerSwap = document.getElementById('timerSwap');
        const lblSwapSub = document.getElementById('lblSwapSubtext');
        const barSwap = document.getElementById('barSwap');

        if (mode === 'DURABILITY') {
            if (badgeSwap) {
                badgeSwap.className = "text-[11px] font-bold px-2 py-0.5 rounded-md bg-cyan-950/60 border border-cyan-800/40 text-cyan-400";
                badgeSwap.innerText = "PATLAMA MODU";
            }
            if (data.rpr && data.rpr.needs_rpr) {
                timerSwap.innerText = "🚨 PATLADI!";
                timerSwap.className = "text-2xl lg:text-3xl font-extrabold font-mono text-rose-400 animate-pulse tracking-tight";
            } else {
                timerSwap.innerText = "⚡ CANLI";
                timerSwap.className = "text-2xl lg:text-3xl font-extrabold font-mono text-cyan-400 tracking-tight";
            }
            if (barSwap) {
                barSwap.style.width = "100%";
                barSwap.className = "bg-gradient-to-r from-cyan-500 to-emerald-400 h-full rounded-full transition-all duration-300";
            }
            if (lblSwapSub) lblSwapSub.innerText = "Silah patlayınca anında yeni çift takar";
        } else if (mode === 'HYBRID') {
            if (badgeSwap) {
                badgeSwap.className = "text-[11px] font-bold px-2 py-0.5 rounded-md bg-amber-950/60 border border-amber-800/40 text-amber-400";
                badgeSwap.innerText = "⚡⏱️ HİBRİT (SAYAÇ + PATLAMA)";
            }
            if (data.rpr && data.rpr.needs_rpr) {
                timerSwap.innerText = "🚨 PATLADI!";
                timerSwap.className = "text-2xl lg:text-3xl font-extrabold font-mono text-rose-400 animate-pulse tracking-tight";
            } else {
                timerSwap.innerText = formatTime(data.swap.remaining_sec);
                timerSwap.className = "text-2xl lg:text-3xl font-extrabold font-mono text-amber-400 tracking-tight";
            }
            const pct = (data.swap.remaining_sec / Math.max(1, data.swap.duration_sec)) * 100;
            if (barSwap) {
                barSwap.style.width = `${Math.min(100, Math.max(0, pct))}%`;
                barSwap.className = "bg-gradient-to-r from-amber-500 to-orange-500 h-full rounded-full transition-all duration-300";
            }
            if (lblSwapSub) lblSwapSub.innerText = `Sayaç: ${formatTime(data.swap.remaining_sec)} • Erken patlarsa anında takar`;
        } else {
            if (badgeSwap) {
                badgeSwap.className = "text-[11px] font-bold px-2 py-0.5 rounded-md bg-blue-950/60 border border-blue-800/40 text-blue-400";
                badgeSwap.innerText = "SAYAÇ";
            }
            timerSwap.innerText = formatTime(data.swap.remaining_sec);
            timerSwap.className = "text-2xl lg:text-3xl font-extrabold font-mono text-white tracking-tight";
            const pct = (data.swap.remaining_sec / Math.max(1, data.swap.duration_sec)) * 100;
            if (barSwap) {
                barSwap.style.width = `${Math.min(100, Math.max(0, pct))}%`;
                barSwap.className = "bg-gradient-to-r from-cyan-500 to-blue-500 h-full rounded-full transition-all duration-300";
            }
            if (lblSwapSub) lblSwapSub.innerText = "Süre bitince yeni çift takar";
        }

        document.getElementById('infoPair').innerText = `Çift ${data.swap.current_pair}/${data.swap.max_pairs} • Bag ${data.swap.active_bag}`;

        if (data.swap.duration_sec && currentTab !== 'settings') {
            const mins = Math.floor(data.swap.duration_sec / 60);
            const secs = data.swap.duration_sec % 60;
            const elMins = document.getElementById('cfgSwapMinutes');
            const elSecs = document.getElementById('cfgSwapSeconds');
            if (elMins && document.activeElement !== elMins) elMins.value = mins;
            if (elSecs && document.activeElement !== elSecs) elSecs.value = secs;
        }

        if (data.swap.trigger_mode && currentTab !== 'settings') {
            const rad = document.querySelector(`input[name="swapTriggerMode"][value="${data.swap.trigger_mode}"]`);
            if (rad) rad.checked = true;
        }
    }

    // 3. VIP Storage Card
    if (data.vip) {
        document.getElementById('timerVip').innerText = formatTime(data.vip.remaining_sec);
        document.getElementById('infoVipSlots').innerText = `${data.vip.slot_count}/${data.vip.slot_count} Slot`;
        const pct = (data.vip.remaining_sec / Math.max(1, data.vip.duration_sec)) * 100;
        document.getElementById('barVip').style.width = `${Math.min(100, Math.max(0, pct))}%`;
    }

    // 3.5 Live Net Profit & Economy Card (Guarded)
    if (data.economy) {
        const hourlyM = data.economy.hourly_net_m;
        const totalNetM = data.economy.net_profit_m;
        const dailyM = data.economy.daily_projected_m;
        const badgeProfit = document.getElementById('badgeProfit');
        const lblHourly = document.getElementById('lblHourlyNet');
        const lblTotal = document.getElementById('lblTotalNet');
        const lblDaily = document.getElementById('lblDailyProjected');

        if (lblHourly) lblHourly.innerText = `${hourlyM >= 0 ? '+' : ''}${hourlyM.toFixed(2)} M`;
        if (lblTotal) lblTotal.innerText = `${totalNetM.toFixed(2)} M`;
        if (lblDaily) lblDaily.innerText = `${dailyM.toFixed(2)} M`;

        if (badgeProfit) {
            if (data.economy.net_profit >= 0) {
                badgeProfit.className = "text-[11px] font-bold px-2 py-0.5 rounded-md bg-emerald-950/60 border border-emerald-800/40 text-emerald-400";
                badgeProfit.innerText = "+NET";
                if (lblHourly) lblHourly.className = "text-2xl lg:text-3xl font-extrabold font-mono text-emerald-400 tracking-tight";
            } else {
                badgeProfit.className = "text-[11px] font-bold px-2 py-0.5 rounded-md bg-rose-950/60 border border-rose-800/40 text-rose-400";
                badgeProfit.innerText = "-ZARAR";
                if (lblHourly) lblHourly.className = "text-2xl lg:text-3xl font-extrabold font-mono text-rose-400 tracking-tight";
            }
        }

        // Update Analytics Tab Elements (if present)
        const elGross = document.getElementById('analyticGross');
        if (elGross) elGross.innerText = `${data.economy.gross_income_m} M`;
        const elExpenses = document.getElementById('analyticExpenses');
        if (elExpenses) elExpenses.innerText = `${(data.economy.total_expenses / 1_000_000).toFixed(2)} M`;
        const elNet = document.getElementById('analyticNet');
        if (elNet) elNet.innerText = `${hourlyM >= 0 ? '+' : ''}${totalNetM.toFixed(2)} M`;

        updateFinancialChart(data.economy);
    }

    // 4. Pot & Pet Telemetry
    const pot = data.pot || data.pet;
    if (pot) {
        const charHp = pot.char_hp !== undefined ? pot.char_hp : 100;
        const charMp = pot.char_mp !== undefined ? pot.char_mp : 100;
        const petHp = pot.pet_hp !== undefined ? pot.pet_hp : 100;
        const petMp = pot.pet_mp !== undefined ? pot.pet_mp : 100;
        const petHunger = pot.pet_hunger !== undefined ? pot.pet_hunger : 100;
        const mobHp = pot.mob_hp !== undefined ? pot.mob_hp : 0;
        const mobState = pot.mob_state || 'HEDEF YOK';

        // Cockpit Card 4 elements
        const lblCharHpHud = document.getElementById('lblCharHpHud');
        const barCharHpHud = document.getElementById('barCharHpHud');
        const lblCharMpHud = document.getElementById('lblCharMpHud');
        const barCharMpHud = document.getElementById('barCharMpHud');
        const lblPetHpHud = document.getElementById('lblPetHpHud');
        const barPetHpHud = document.getElementById('barPetHpHud');
        const lblPetMpHud = document.getElementById('lblPetMpHud');
        const barPetMpHud = document.getElementById('barPetMpHud');
        const lblPetHungerHud = document.getElementById('lblPetHungerHud');
        const lblMobHpHud = document.getElementById('lblMobHpHud');
        const barMobHud = document.getElementById('barMobHud');
        const lblMobStateHud = document.getElementById('lblMobStateHud');

        if (lblCharHpHud) lblCharHpHud.innerText = `%${charHp}`;
        if (barCharHpHud) barCharHpHud.style.width = `${Math.min(100, Math.max(0, charHp))}%`;
        if (lblCharMpHud) lblCharMpHud.innerText = `%${charMp}`;
        if (barCharMpHud) barCharMpHud.style.width = `${Math.min(100, Math.max(0, charMp))}%`;

        if (lblPetHpHud) lblPetHpHud.innerText = `%${petHp}`;
        if (barPetHpHud) barPetHpHud.style.width = `${Math.min(100, Math.max(0, petHp))}%`;
        if (lblPetMpHud) lblPetMpHud.innerText = `%${petMp}`;
        if (barPetMpHud) barPetMpHud.style.width = `${Math.min(100, Math.max(0, petMp))}%`;
        if (lblPetHungerHud) lblPetHungerHud.innerText = `%${petHunger}`;

        if (lblMobHpHud) lblMobHpHud.innerText = `%${mobHp}`;
        if (barMobHud) barMobHud.style.width = `${Math.min(100, Math.max(0, mobHp))}%`;
        if (lblMobStateHud) lblMobStateHud.innerText = mobState;

        // Dedicated Pot Tab elements
        const lblCharHpVal = document.getElementById('lblCharHpVal');
        const barCharHpLive = document.getElementById('barCharHpLive');
        const lblCharMpVal = document.getElementById('lblCharMpVal');
        const barCharMpLive = document.getElementById('barCharMpLive');
        const lblPetHpVal = document.getElementById('lblPetHpVal');
        const barPetHpLive = document.getElementById('barPetHpLive');
        const lblPetMpVal = document.getElementById('lblPetMpVal');
        const barPetMpLive = document.getElementById('barPetMpLive');
        const lblPetHungerVal = document.getElementById('lblPetHungerVal');
        const barPetHungerLive = document.getElementById('barPetHungerLive');
        const lblMobHpVal = document.getElementById('lblMobHpVal');
        const barMobHpLive = document.getElementById('barMobHpLive');
        const lblMobStateVal = document.getElementById('lblMobStateVal');

        if (lblCharHpVal) lblCharHpVal.innerText = `%${charHp}`;
        if (barCharHpLive) barCharHpLive.style.width = `${Math.min(100, Math.max(0, charHp))}%`;
        if (lblCharMpVal) lblCharMpVal.innerText = `%${charMp}`;
        if (barCharMpLive) barCharMpLive.style.width = `${Math.min(100, Math.max(0, charMp))}%`;

        if (lblPetHpVal) lblPetHpVal.innerText = `%${petHp}`;
        if (barPetHpLive) barPetHpLive.style.width = `${Math.min(100, Math.max(0, petHp))}%`;
        if (lblPetMpVal) lblPetMpVal.innerText = `%${petMp}`;
        if (barPetMpLive) barPetMpLive.style.width = `${Math.min(100, Math.max(0, petMp))}%`;
        if (lblPetHungerVal) lblPetHungerVal.innerText = `%${petHunger}`;
        if (barPetHungerLive) barPetHungerLive.style.width = `${Math.min(100, Math.max(0, petHunger))}%`;

        if (lblMobHpVal) lblMobHpVal.innerText = `%${mobHp}`;
        if (barMobHpLive) barMobHpLive.style.width = `${Math.min(100, Math.max(0, mobHp))}%`;
        if (lblMobStateVal) lblMobStateVal.innerText = mobState;

        // Legacy / fallback elements
        const lblMobHp = document.getElementById('lblMobHp');
        if (lblMobHp) lblMobHp.innerText = `%${mobHp}`;
        const lblPetHp = document.getElementById('lblPetHp');
        if (lblPetHp) lblPetHp.innerText = `%${petHp}`;
        const lblPetMp = document.getElementById('lblPetMp');
        if (lblPetMp) lblPetMp.innerText = `%${petMp}`;
        const lblMobState = document.getElementById('lblMobState');
        if (lblMobState) lblMobState.innerText = mobState;
        const barMob = document.getElementById('barMob');
        if (barMob) barMob.style.width = `${Math.min(100, Math.max(0, mobHp))}%`;

        // Badges and buttons
        const isRunning = Boolean(pot.running);
        ['badgePetBotStatus', 'badgePotBotStatus'].forEach(bId => {
            const b = document.getElementById(bId);
            if (b) {
                b.innerText = isRunning ? "ÇALIŞIYOR (F9)" : "DURDURULDU (F9)";
                b.className = isRunning
                    ? "px-3 py-1 rounded-lg text-xs font-bold bg-emerald-950 border border-emerald-800 text-emerald-400 animate-pulse"
                    : "px-3 py-1 rounded-lg text-xs font-bold bg-slate-900 border border-slate-700 text-slate-400";
            }
        });

        ['btnTogglePetBot', 'btnTogglePotBot'].forEach(btnId => {
            const btn = document.getElementById(btnId);
            if (btn) {
                btn.className = isRunning
                    ? "px-4 py-2 rounded-xl text-xs font-bold bg-rose-600 hover:bg-rose-500 text-white transition flex items-center gap-2 glow-rose"
                    : "px-4 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white transition flex items-center gap-2 glow-emerald";
            }
        });

        const potIcon = document.getElementById('btnPotIcon') || document.getElementById('btnPetIcon');
        if (potIcon) potIcon.innerText = isRunning ? "⏹" : "▶";
        const potText = document.getElementById('btnPotText') || document.getElementById('btnPetText');
        if (potText) potText.innerText = isRunning ? "HP/MP & PET BOTU DURDUR (F9)" : "HP/MP & PET BOTU BAŞLAT (F9)";
    }

    // 4.1 Anvil Upgrade Telemetry
    if (data.anvil) {
        const badgeAnvil = document.getElementById('badgeAnvilStatus');
        const btnAnvil = document.getElementById('btnToggleAnvil');
        const btnAnvilIcon = document.getElementById('btnAnvilIcon');
        const btnAnvilText = document.getElementById('btnAnvilText');
        const lblPass = document.getElementById('lblAnvilPass');
        const lblItem = document.getElementById('lblAnvilItem');
        const barProgress = document.getElementById('barAnvilProgress');

        if (lblPass) lblPass.innerText = `${data.anvil.current_pass} / ${data.anvil.passes}`;
        if (lblItem) lblItem.innerText = `${data.anvil.current_item} / ${data.anvil.total_items}`;
        if (barProgress && data.anvil.total_items > 0) {
            const pct = Math.round((data.anvil.current_item / data.anvil.total_items) * 100);
            barProgress.style.width = `${pct}%`;
        }

        if (data.anvil.running) {
            if (badgeAnvil) {
                badgeAnvil.innerText = "ÇALIŞIYOR (F1)";
                badgeAnvil.className = "px-3 py-1 rounded-lg text-xs font-bold bg-emerald-950 border border-emerald-800 text-emerald-400 animate-pulse";
            }
            if (btnAnvil) {
                btnAnvil.className = "px-6 py-3 rounded-xl font-bold text-xs bg-rose-600 hover:bg-rose-500 text-white transition flex items-center justify-center gap-2 glow-rose active:scale-95";
                if (btnAnvilIcon) btnAnvilIcon.innerText = "⏹";
                if (btnAnvilText) btnAnvilText.innerText = "ANVIL DURDUR (F1)";
            }
        } else {
            if (badgeAnvil) {
                badgeAnvil.innerText = "DURDURULDU (F1)";
                badgeAnvil.className = "px-3 py-1 rounded-lg text-xs font-bold bg-slate-900 border border-slate-700 text-slate-400";
            }
            if (btnAnvil) {
                btnAnvil.className = "px-6 py-3 rounded-xl font-bold text-xs bg-emerald-600 hover:bg-emerald-500 text-white transition flex items-center justify-center gap-2 glow-emerald active:scale-95";
                if (btnAnvilIcon) btnAnvilIcon.innerText = "▶";
                if (btnAnvilText) btnAnvilText.innerText = "ANVIL UPGRADE BAŞLAT (F1)";
            }
        }
    }

    // 4.2 Privacy Shield Telemetry
    if (data.privacy) {
        const btnDim = document.getElementById('btnToggleDimmer');
        const btnGhost = document.getElementById('btnToggleGhost');
        if (btnDim) {
            btnDim.innerText = data.privacy.dimmer_active ? "AKTİF" : "PASİF";
            btnDim.className = data.privacy.dimmer_active 
                ? "px-3 py-1 rounded-lg text-xs font-bold bg-emerald-950 border border-emerald-800 text-emerald-400"
                : "px-3 py-1 rounded-lg text-xs font-bold bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 transition";
        }
        if (btnGhost) {
            btnGhost.innerText = data.privacy.ghost_active ? "AKTİF" : "PASİF";
            btnGhost.className = data.privacy.ghost_active 
                ? "px-3 py-1 rounded-lg text-xs font-bold bg-emerald-950 border border-emerald-800 text-emerald-400"
                : "px-3 py-1 rounded-lg text-xs font-bold bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 transition";
        }

        const btnHud = document.getElementById('btnToggleMiniHud');
        const lblHud = document.getElementById('lblMiniHudStatus');
        if (btnHud && lblHud) {
            const isHudActive = !!data.privacy.mini_hud_active;
            lblHud.innerText = isHudActive ? "Mini HUD: AÇIK" : "Mini HUD: KAPALI";
            btnHud.className = isHudActive
                ? "px-3.5 py-2 rounded-xl text-xs font-bold bg-cyan-950/90 border border-cyan-500 text-cyan-300 shadow-md shadow-cyan-900/40 glow-cyan transition flex items-center gap-1.5 cursor-pointer"
                : "px-3.5 py-2 rounded-xl text-xs font-bold bg-slate-800/80 hover:bg-slate-700 border border-slate-700/80 text-slate-300 transition flex items-center gap-1.5 cursor-pointer";
        }
    }

    // 4.5 Minimap Autonomous Navigator Telemetry
    if (data.navigator) {
        const nav = data.navigator;
        const lblHeading = document.getElementById('lblNavHeading');
        const lblTarget = document.getElementById('lblNavTargetHeading');
        const lblDist = document.getElementById('lblNavDistance');
        const lblWp = document.getElementById('lblNavWaypoints');
        const badgeStatus = document.getElementById('badgeNavStatus');
        const badgeSteering = document.getElementById('badgeNavSteering');

        if (lblHeading) lblHeading.innerText = `${nav.heading_deg}°`;
        if (lblTarget) lblTarget.innerText = `${nav.target_heading_deg}°`;
        if (lblDist) lblDist.innerText = `${nav.distance} px`;
        if (lblWp) lblWp.innerText = `${nav.current_wp} / ${nav.total_wp} WP`;

        if (badgeStatus) {
            if (nav.recording) {
                badgeStatus.className = "text-xs font-bold font-mono px-3 py-1 rounded-lg bg-rose-950/80 border border-rose-800 text-rose-300 animate-pulse";
                badgeStatus.innerText = "🔴 ROTA KAYDEDİLİYOR";
            } else if (nav.active) {
                badgeStatus.className = "text-xs font-bold font-mono px-3 py-1 rounded-lg bg-emerald-950/80 border border-emerald-800 text-emerald-300 glow-emerald";
                badgeStatus.innerText = `🚀 OTONOM PİLOT: ${nav.mode}`;
            } else {
                badgeStatus.className = "text-xs font-bold font-mono px-3 py-1 rounded-lg bg-slate-800/80 border border-slate-700 text-slate-300";
                badgeStatus.innerText = "BEKLEMEDE (IDLE)";
            }
        }

        if (badgeSteering) {
            let steerText = "DURUYOR";
            let steerClass = "bg-slate-800 border-slate-700 text-slate-400";
            if (nav.steering === 'MOVE_FORWARD') {
                steerText = "DÜZ GİT [W]";
                steerClass = "bg-emerald-950/80 border-emerald-800 text-emerald-300";
            } else if (nav.steering === 'TURN_LEFT') {
                steerText = "SOLA DÖN [A]";
                steerClass = "bg-cyan-950/80 border-cyan-800 text-cyan-300";
            } else if (nav.steering === 'TURN_RIGHT') {
                steerText = "SAĞA DÖN [D]";
                steerClass = "bg-blue-950/80 border-blue-800 text-blue-300";
            } else if (nav.steering === 'RECOVERY_UNSTUCK') {
                steerText = "⚠️ ENGEL AŞILIYOR (S+D)";
                steerClass = "bg-amber-950/80 border-amber-800 text-amber-300 animate-bounce";
            }
            badgeSteering.className = `text-xs font-bold font-mono px-3 py-1 rounded-lg border ${steerClass}`;
            badgeSteering.innerText = `DİREKSİYON: ${steerText}`;
        }
    }

    // 4.6 Loot & Drop Vault Telemetry
    if (data.loot) {
        renderLoot(data.loot);
    }

    // 4.7 Calibration & Coordinate Telemetry
    if (data.calibration) {
        const c = data.calibration.coords || {};
        const rpr = data.calibration.rpr_rect || {};
        if (c.Genie) {
            const el = document.getElementById('coordGenie');
            if (el) el.innerText = `X: ${c.Genie.x}, Y: ${c.Genie.y}`;
        }
        if (c.VIP_Open) {
            const el = document.getElementById('coordVipOpen');
            if (el) el.innerText = `X: ${c.VIP_Open.x}, Y: ${c.VIP_Open.y}`;
        }
        if (c.VipConfirm) {
            const el = document.getElementById('coordVipConfirm');
            if (el) el.innerText = `X: ${c.VipConfirm.x}, Y: ${c.VipConfirm.y}`;
        }
        if (rpr.rel_x !== undefined) {
            const el = document.getElementById('coordRpr');
            if (el) el.innerText = `${rpr.rel_x}, ${rpr.rel_y} (${rpr.w}x${rpr.h})`;
        }
        if (data.calibration.vip_confirm_mode) {
            updateVipConfirmBadge(data.calibration.vip_confirm_mode);
            const rad = document.querySelector(`input[name="vipConfirmMode"][value="${data.calibration.vip_confirm_mode}"]`);
            if (rad && currentTab !== 'wizard') rad.checked = true;
        }
    }

    // 5. Render Logs
    if (data.recent_logs) {
        allLogs = data.recent_logs;
        renderLogs();
    }

    // 6. Remote Public Access Tunnel (Cloudflare)
    if (data.remote_access) {
        const banner = document.getElementById('bannerRemoteAccess');
        const lnk = document.getElementById('lnkRemoteUrl');
        const btn = document.getElementById('btnRemoteTunnel');
        const lbl = document.getElementById('lblRemoteStatus');

        if (data.remote_access.active && data.remote_access.url) {
            currentRemoteUrl = data.remote_access.url;
            if (banner) banner.classList.remove('hidden');
            if (lnk) {
                lnk.href = data.remote_access.url;
                lnk.innerText = data.remote_access.url;
            }
            const modalUrlInp = document.getElementById('modalRemoteUrlInput');
            if (modalUrlInp) modalUrlInp.value = currentRemoteUrl;
            const loadingBox = document.getElementById('remoteLoadingBox');
            const readyBox = document.getElementById('remoteReadyBox');
            if (loadingBox && readyBox) {
                loadingBox.classList.add('hidden');
                readyBox.classList.remove('hidden');
            }
            if (btn) {
                btn.className = "flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-bold bg-cyan-950 border-cyan-500 text-cyan-300 transition glow-cyan";
            }
            if (lbl) lbl.innerText = "Uzaktan: AÇIK";
        } else {
            currentRemoteUrl = "";
            if (banner) banner.classList.add('hidden');
            if (btn) {
                btn.className = "flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold bg-slate-800/60 hover:bg-slate-700/60 border-slate-700/60 text-slate-300 transition";
            }
            if (lbl) lbl.innerText = "Uzaktan Erişim";
        }
    }

    // 7. Slot Matrix Synchronization
    if (data.locked_vip_slots && Array.isArray(data.locked_vip_slots)) {
        let changed = (data.locked_vip_slots.length !== lockedSlotsVIP.size);
        if (!changed) {
            for (let v of data.locked_vip_slots) {
                if (!lockedSlotsVIP.has(v)) { changed = true; break; }
            }
        }
        if (changed) {
            lockedSlotsVIP = new Set(data.locked_vip_slots);
            buildSlotMatrices();
        }
    }
    if (data.locked_bag_slots && Array.isArray(data.locked_bag_slots)) {
        let changedBag = (data.locked_bag_slots.length !== lockedSlotsBag.size);
        if (!changedBag) {
            for (let b of data.locked_bag_slots) {
                if (!lockedSlotsBag.has(b)) { changedBag = true; break; }
            }
        }
        if (changedBag) {
            lockedSlotsBag = new Set(data.locked_bag_slots);
            buildSlotMatrices();
        }
    }

    // 8. Mandatory Auto-Updater Telemetry
    if (data.update) {
        handleUpdateTelemetry(data.update);
    }
}


// --- Live Viewport Stream Engine ---
function toggleLiveStream() {
    playUiClick();
    streamActive = !streamActive;
    const btn = document.getElementById('btnStreamToggle');
    if (streamActive) {
        btn.innerText = "Canlı Akış: AÇIK";
        btn.className = "px-2.5 py-1 rounded-md text-[11px] font-bold bg-cyan-950/80 border border-cyan-800/60 text-cyan-300 hover:bg-cyan-900/60 transition";
        startStreamLoop();
    } else {
        btn.innerText = "Canlı Akış: KAPALI";
        btn.className = "px-2.5 py-1 rounded-md text-[11px] font-bold bg-slate-800/80 border border-slate-700/60 text-slate-400 hover:bg-slate-700/60 transition";
        stopStreamLoop();
    }
}

function refreshSnapshot() {
    playUiClick();
    const newSrc = `/api/snapshot?t=${Date.now()}`;
    const img = document.getElementById('liveSnapshotImg');
    if (img) img.src = newSrc;
    const fsImg = document.getElementById('fullscreenStreamImg');
    if (fsImg) fsImg.src = newSrc;
}

function startStreamLoop() {
    if (streamInterval) clearInterval(streamInterval);
    streamInterval = setInterval(() => {
        if (streamActive && (currentTab === 'cockpit' || isFullscreenStreamOpen)) {
            const newSrc = `/api/snapshot?t=${Date.now()}`;
            const img = document.getElementById('liveSnapshotImg');
            if (img) img.src = newSrc;
            const fsImg = document.getElementById('fullscreenStreamImg');
            if (fsImg && isFullscreenStreamOpen) fsImg.src = newSrc;
        }
    }, 1200); // 1.2s interval zero-lag
}

function stopStreamLoop() {
    if (streamInterval) {
        clearInterval(streamInterval);
        streamInterval = null;
    }
}

// --- Live Fullscreen Lightbox Stream (Mobil & Masaüstü) ---
let isFullscreenStreamOpen = false;

function toggleFullscreenStream() {
    playUiClick();
    const modal = document.getElementById('fullscreenStreamModal');
    if (!modal) return;
    isFullscreenStreamOpen = !isFullscreenStreamOpen;
    if (isFullscreenStreamOpen) {
        modal.classList.remove('hidden');
        const fsImg = document.getElementById('fullscreenStreamImg');
        const liveImg = document.getElementById('liveSnapshotImg');
        if (fsImg && liveImg) fsImg.src = liveImg.src;
    } else {
        modal.classList.add('hidden');
    }
}

// --- Remote Access Public Tunnel Controls & Modal ---
let currentRemoteUrl = "";

async function openRemoteModal() {
    playUiClick();
    const modal = document.getElementById('remoteModal');
    if (modal) modal.classList.remove('hidden');

    const loadingBox = document.getElementById('remoteLoadingBox');
    const readyBox = document.getElementById('remoteReadyBox');
    const urlInp = document.getElementById('modalRemoteUrlInput');
    const btnToggle = document.getElementById('btnModalToggleTunnel');

    if (currentRemoteUrl) {
        if (loadingBox) loadingBox.classList.add('hidden');
        if (readyBox) readyBox.classList.remove('hidden');
        if (urlInp) urlInp.value = currentRemoteUrl;
        if (btnToggle) btnToggle.innerText = "Tüneli Durdur";
        return;
    }

    // Tünel henüz açık değilse otomatik olarak başlat
    if (loadingBox) {
        loadingBox.classList.remove('hidden');
        loadingBox.innerHTML = `
            <div class="w-8 h-8 mx-auto border-2 border-cyan-500 border-t-transparent rounded-full animate-spin"></div>
            <div class="text-xs font-bold text-cyan-400">Cloudflare Edge Ağına Bağlanılıyor...</div>
            <p class="text-[11px] text-slate-400">Güvenli HTTPS tüneli oluşturuluyor, lütfen 3-5 saniye bekleyin.</p>
        `;
    }
    if (readyBox) readyBox.classList.add('hidden');

    try {
        const res = await authFetch('/api/tunnel/toggle', { method: 'POST' });
        const data = await res.json();
        if (data.active && data.url) {
            currentRemoteUrl = data.url;
            playSuccessChirp();
            if (loadingBox) loadingBox.classList.add('hidden');
            if (readyBox) readyBox.classList.remove('hidden');
            if (urlInp) urlInp.value = data.url;
            if (btnToggle) btnToggle.innerText = "Tüneli Durdur";
        } else {
            if (loadingBox) {
                loadingBox.innerHTML = `
                    <div class="text-rose-400 font-bold text-xs">❌ Tünel başlatılamadı.</div>
                    <p class="text-[11px] text-slate-400 mt-1">Lütfen tools/cloudflared.exe dosyasının mevcut olduğunu kontrol edin.</p>
                    <button onclick="openRemoteModal()" class="mt-2 px-3 py-1 rounded bg-cyan-600 text-white text-xs font-bold">Tekrar Dene</button>
                `;
            }
        }
    } catch (e) {
        if (loadingBox) {
            loadingBox.innerHTML = `<div class="text-rose-400 font-bold text-xs">Bağlantı hatası: ${e}</div>`;
        }
    }
}

function closeRemoteModal() {
    playUiClick();
    const modal = document.getElementById('remoteModal');
    if (modal) modal.classList.add('hidden');
}

function copyModalRemoteUrl() {
    const urlInp = document.getElementById('modalRemoteUrlInput');
    const url = urlInp ? urlInp.value : currentRemoteUrl;
    if (url && url !== '...') {
        navigator.clipboard.writeText(url).then(() => {
            playSuccessChirp();
            alert('✔ Uzaktan erişim bağlantısı panoya kopyalandı:\n\n' + url + '\n\nBu linki telefonunuza WhatsApp, Telegram veya SMS ile gönderip hücresel verinizle (4G/5G) dilediğiniz yerden paneli izleyebilirsiniz!');
        });
    }
}

async function toggleRemoteTunnelBackend() {
    playUiClick();
    const loadingBox = document.getElementById('remoteLoadingBox');
    const readyBox = document.getElementById('remoteReadyBox');
    const btnToggle = document.getElementById('btnModalToggleTunnel');

    if (currentRemoteUrl) {
        try {
            await authFetch('/api/tunnel/toggle', { method: 'POST' });
            currentRemoteUrl = "";
            if (readyBox) readyBox.classList.add('hidden');
            if (loadingBox) {
                loadingBox.classList.remove('hidden');
                loadingBox.innerHTML = `
                    <div class="text-amber-400 font-bold text-xs">🌐 Tünel durduruldu.</div>
                    <button onclick="openRemoteModal()" class="mt-2 px-3 py-1 rounded bg-cyan-600 text-white text-xs font-bold">Tekrar Başlat</button>
                `;
            }
            if (btnToggle) btnToggle.innerText = "Tüneli Başlat";
        } catch (e) {}
    } else {
        openRemoteModal();
    }
}

function toggleRemoteTunnel() {
    openRemoteModal();
}

function copyRemoteUrl() {
    copyModalRemoteUrl();
}


// --- Interactive Slot Matrix Visualizer ---
function buildSlotMatrices() {
    const vipContainer = document.getElementById('vipGridMatrix');
    vipContainer.innerHTML = '';
    for (let i = 1; i <= 28; i++) {
        const slot = document.createElement('div');
        slot.id = `vip-slot-${i}`;
        slot.className = `slot-cell p-2 text-center text-xs font-mono font-bold ${lockedSlotsVIP.has(i) ? 'locked' : 'text-slate-300'}`;
        slot.innerHTML = `
            <span class="text-[9px] text-slate-500 font-normal">#${i}</span>
            <span class="text-base my-0.5">${lockedSlotsVIP.has(i) ? '🔒' : '📦'}</span>
            <span class="text-[9px] ${lockedSlotsVIP.has(i) ? 'text-rose-400' : 'text-cyan-400'}">${lockedSlotsVIP.has(i) ? 'KİLİTLİ' : 'AKTAR'}</span>
        `;
        slot.onclick = () => toggleVipSlot(i);
        vipContainer.appendChild(slot);
    }

    const bagContainer = document.getElementById('bagGridMatrix');
    bagContainer.innerHTML = '';
    for (let i = 1; i <= 12; i++) {
        const slot = document.createElement('div');
        slot.id = `bag-slot-${i}`;
        slot.className = `slot-cell p-2 text-center text-xs font-mono font-bold ${lockedSlotsBag.has(i) ? 'locked' : 'text-slate-300'}`;
        slot.innerHTML = `
            <span class="text-[9px] text-slate-500 font-normal">#${i}</span>
            <span class="text-base my-0.5">${lockedSlotsBag.has(i) ? '🔒' : '🎒'}</span>
            <span class="text-[9px] ${lockedSlotsBag.has(i) ? 'text-rose-400' : 'text-emerald-400'}">${lockedSlotsBag.has(i) ? 'KİLİTLİ' : 'SERBEST'}</span>
        `;
        slot.onclick = () => toggleBagSlot(i);
        bagContainer.appendChild(slot);
    }
}

function syncLockedSlotsToServer() {
    sendAction('update_locked_slots', {
        locked_vip: Array.from(lockedSlotsVIP),
        locked_bag: Array.from(lockedSlotsBag)
    });
}

function toggleVipSlot(idx) {
    playUiClick();
    if (lockedSlotsVIP.has(idx)) {
        lockedSlotsVIP.delete(idx);
    } else {
        lockedSlotsVIP.add(idx);
    }
    buildSlotMatrices();
    syncLockedSlotsToServer();
}

function toggleBagSlot(idx) {
    playUiClick();
    if (lockedSlotsBag.has(idx)) {
        lockedSlotsBag.delete(idx);
    } else {
        lockedSlotsBag.add(idx);
    }
    buildSlotMatrices();
    syncLockedSlotsToServer();
}

function lockFirstFourSlots() {
    playUiClick();
    for (let i = 1; i <= 4; i++) {
        lockedSlotsVIP.add(i);
    }
    buildSlotMatrices();
    syncLockedSlotsToServer();
}

function lockAllVipSlots() {
    playUiClick();
    for (let i = 1; i <= 28; i++) {
        lockedSlotsVIP.add(i);
    }
    buildSlotMatrices();
    syncLockedSlotsToServer();
}

function unlockAllVipSlots() {
    playUiClick();
    lockedSlotsVIP.clear();
    buildSlotMatrices();
    syncLockedSlotsToServer();
}

// --- Tab Navigation Engine ---
let currentLootFilter = 'ALL';
let allLootDrops = [];

function switchTab(tabId) {
    playUiClick();
    if (tabId === 'wizard') tabId = 'calib';
    currentTab = tabId;
    ['cockpit', 'calib', 'pot', 'anvil', 'matrix', 'settings'].forEach(id => {
        const view = document.getElementById(`view-${id}`);
        const btn = document.getElementById(`tab-${id}`);
        if (!view) return;
        if (id === tabId) {
            view.classList.remove('hidden');
            if (btn) btn.className = "px-3.5 py-2 rounded-lg bg-cyan-950/80 text-cyan-400 border border-cyan-800/60 flex items-center gap-2 transition glow-cyan shrink-0";
        } else {
            view.classList.add('hidden');
            if (btn) btn.className = "px-3.5 py-2 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800/40 border border-transparent transition flex items-center gap-2 shrink-0";
        }
    });

    if (tabId === 'matrix') {
        buildSlotMatrices();
    }
    if (tabId === 'anvil') {
        buildAnvilSlotMatrix();
    }
}

// --- Anvil Interactive Slot Matrix Visualizer (28 Slots) ---
function buildAnvilSlotMatrix() {
    const container = document.getElementById('anvilSlotMatrixGrid');
    if (!container) return;
    container.innerHTML = '';

    const startSlot = parseInt(document.getElementById('cfgAnvilStart')?.value) || 2;
    const endSlot = parseInt(document.getElementById('cfgAnvilEnd')?.value) || 28;

    for (let i = 1; i <= 28; i++) {
        const slotEl = document.createElement('div');
        slotEl.className = "p-2 rounded-xl border flex flex-col items-center justify-center transition cursor-pointer select-none text-center ";

        if (i === 1) {
            slotEl.className += "bg-amber-950/40 border-amber-600/60 text-amber-300 cursor-default";
            slotEl.innerHTML = `<span class="text-[10px] font-mono text-amber-400 font-extrabold">SLOT 1</span>
                                <span class="text-[9px] font-bold text-amber-200 mt-0.5">📜 SCROLL</span>`;
        } else if (i >= startSlot && i <= endSlot) {
            slotEl.className += "bg-emerald-950/50 border-emerald-500/60 text-emerald-300 hover:border-emerald-400 glow-emerald";
            slotEl.innerHTML = `<span class="text-xs font-mono font-extrabold text-white">${i}</span>
                                <span class="text-[9px] font-bold text-emerald-400 mt-0.5">✔ BASILACAK</span>`;
            slotEl.onclick = () => onAnvilSlotClick(i);
        } else {
            slotEl.className += "bg-slate-950/60 border-slate-800/80 text-slate-500 hover:border-slate-700 hover:text-slate-300";
            slotEl.innerHTML = `<span class="text-xs font-mono font-bold text-slate-500">${i}</span>
                                <span class="text-[9px] text-slate-600 mt-0.5">ATLANACAK</span>`;
            slotEl.onclick = () => onAnvilSlotClick(i);
        }

        container.appendChild(slotEl);
    }

    const summary = document.getElementById('lblAnvilSelectedSummary');
    if (summary) {
        const count = Math.max(0, endSlot - startSlot + 1);
        summary.innerText = `Slot ${startSlot} - ${endSlot} (${count} Slot Seçili)`;
    }
}

function onAnvilSlotClick(slotNum) {
    playUiClick();
    let startSlot = parseInt(document.getElementById('cfgAnvilStart')?.value) || 2;
    let endSlot = parseInt(document.getElementById('cfgAnvilEnd')?.value) || 28;

    if (slotNum < startSlot) {
        document.getElementById('cfgAnvilStart').value = slotNum;
    } else if (slotNum > endSlot) {
        document.getElementById('cfgAnvilEnd').value = slotNum;
    } else {
        if (Math.abs(slotNum - startSlot) <= Math.abs(slotNum - endSlot)) {
            document.getElementById('cfgAnvilStart').value = Math.min(slotNum + 1, endSlot);
        } else {
            document.getElementById('cfgAnvilEnd').value = Math.max(slotNum - 1, startSlot);
        }
    }

    buildAnvilSlotMatrix();
    saveAnvilSettings();
}

function setAnvilRangePreset(start, end) {
    playUiClick();
    const elStart = document.getElementById('cfgAnvilStart');
    const elEnd = document.getElementById('cfgAnvilEnd');
    if (elStart) elStart.value = start;
    if (elEnd) elEnd.value = end;
    buildAnvilSlotMatrix();
    saveAnvilSettings();
}

// --- Wizard & Calibration Controls ---
function startWizardCalibration(target) {
    playUiClick();
    sendAction('start_calibration', { target: target });
    alert(`🎯 [${target}] Kalibrasyonu Başlatıldı!\n\n🔍 5X Canlı Büyüteç (Milimetrik Zoom Loupe) farenizi takip edecektir.\nLütfen istenen noktanın / barın üzerine gelin ve [SPACE] tuşuna basın.\nİptal etmek için [ESC] tuşuna basabilirsiniz.`);
}

function changeVipConfirmMode(mode) {
    playUiClick();
    sendAction('set_vip_confirm_mode', { mode: mode });
    updateVipConfirmBadge(mode);
}

function updateVipConfirmBadge(mode) {
    const badge = document.getElementById('badgeVipConfirmMode');
    if (!badge) return;
    if (mode === 'click') {
        badge.innerText = "SOL TIK AKTİF";
        badge.className = "text-xs font-mono font-bold px-3 py-1 rounded-lg bg-cyan-950 border border-cyan-800 text-cyan-300";
    } else if (mode === 'enter') {
        badge.innerText = "ENTER AKTİF";
        badge.className = "text-xs font-mono font-bold px-3 py-1 rounded-lg bg-slate-900 border border-slate-700 text-slate-300";
    } else {
        badge.innerText = "SOL TIK + ENTER";
        badge.className = "text-xs font-mono font-bold px-3 py-1 rounded-lg bg-amber-950 border border-amber-800 text-amber-300";
    }
}

function resetCoordinates() {
    if (confirm("Tüm koordinatlar varsayılan 1600x900 fabrika ayarlarına döndürülsün mü?")) {
        playUiClick();
        sendAction('reset_coordinates');
        alert("↺ Tüm koordinatlar fabrika standartlarına sıfırlandı!");
    }
}

function saveAnvilSettings() {
    playUiClick();
    const speed = document.getElementById('cfgAnvilSpeed').value;
    const anim = document.getElementById('cfgAnvilAnim').value;
    const passes = document.getElementById('cfgAnvilPasses').value;
    const start = document.getElementById('cfgAnvilStart').value;
    const end = document.getElementById('cfgAnvilEnd').value;
    sendAction('update_anvil_settings', {
        speed_ms: speed,
        anim_delay_ms: anim,
        passes: passes,
        start_slot: start,
        end_slot: end
    });
    buildAnvilSlotMatrix();
}

function saveAllPotSettings(silent = false) {
    if (!silent) playUiClick();
    const payload = {
        char_hp_active: document.getElementById('chkCharHpActive')?.checked ?? true,
        char_hp_th: parseInt(document.getElementById('cfgCharHpTh')?.value) || 70,
        char_hp_key: document.getElementById('cfgCharHpKey')?.value?.trim() || "1",
        char_mp_active: document.getElementById('chkCharMpActive')?.checked ?? true,
        char_mp_th: parseInt(document.getElementById('cfgCharMpTh')?.value) || 50,
        char_mp_key: document.getElementById('cfgCharMpKey')?.value?.trim() || "2",
        pet_hp_active: document.getElementById('chkPetHpActive')?.checked ?? true,
        pet_hp_th: parseInt(document.getElementById('cfgPetHpTh')?.value) || 40,
        pet_hp_key: document.getElementById('cfgPetHpKey')?.value?.trim() || "4",
        pet_mp_active: document.getElementById('chkPetMpActive')?.checked ?? true,
        pet_mp_th: parseInt(document.getElementById('cfgPetMpTh')?.value) || 40,
        pet_mp_key: document.getElementById('cfgPetMpKey')?.value?.trim() || "5",
        pet_hunger_active: document.getElementById('chkPetHungerActive')?.checked ?? true,
        pet_hunger_th: parseInt(document.getElementById('cfgPetHungerTh')?.value) || 20,
        feed_active: document.getElementById('chkPetFeedActive')?.checked ?? false,
        feed_interval_min: parseInt(document.getElementById('cfgPetFeedMin')?.value) || 60
    };
    sendAction('update_pot_settings', payload);
    if (!silent) playSuccessChirp();
}

function savePetSettings() {
    saveAllPotSettings();
}

function attachAutoSaveListeners() {
    // 1. HP/MP Pot & Pet Değişikliklerini Butona Basmaya Gerek Kalmadan Otomatik Kaydet
    const potInputIds = [
        'chkCharHpActive', 'cfgCharHpTh', 'cfgCharHpKey',
        'chkCharMpActive', 'cfgCharMpTh', 'cfgCharMpKey',
        'chkPetHpActive', 'cfgPetHpTh', 'cfgPetHpKey',
        'chkPetMpActive', 'cfgPetMpTh', 'cfgPetMpKey',
        'chkPetHungerActive', 'cfgPetHungerTh',
        'chkPetFeedActive', 'cfgPetFeedMin'
    ];
    let potDebounce = null;
    potInputIds.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            const ev = (el.type === 'checkbox') ? 'change' : 'input';
            el.addEventListener(ev, () => {
                clearTimeout(potDebounce);
                potDebounce = setTimeout(() => {
                    saveAllPotSettings(true);
                }, 350);
            });
        }
    });

    // 2. Anvil Değerlerini Otomatik Kaydet
    const anvilIds = ['cfgAnvilSpeed', 'cfgAnvilAnim', 'cfgAnvilPasses', 'cfgAnvilStart', 'cfgAnvilEnd'];
    let anvilDebounce = null;
    anvilIds.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.addEventListener('input', () => {
                clearTimeout(anvilDebounce);
                anvilDebounce = setTimeout(() => {
                    saveAnvilSettings();
                }, 400);
            });
        }
    });
}

// --- Loot Vault Engine ---
function renderLoot(loot) {
    if (!loot) return;
    const lblCoins = document.getElementById('lblLootCoins');
    const lblItems = document.getElementById('lblLootItems');
    const lblVal = document.getElementById('lblLootValuable');
    const lblVault = document.getElementById('lblLootVault');
    
    if (lblCoins) lblCoins.innerText = `${loot.total_coins_m} M`;
    if (lblItems) lblItems.innerText = `${loot.total_items} Adet`;
    if (lblVal) lblVal.innerText = `${loot.valuable_count} Adet`;
    if (lblVault) lblVault.innerText = `+${loot.total_vault_m} M`;

    // OCR Durum ve Metin Göstergeleri
    const lblOcrText = document.getElementById('lblLastOcrText');
    if (lblOcrText && loot.last_scanned_text) {
        lblOcrText.innerText = loot.last_scanned_text;
    }

    const badgeOcr = document.getElementById('badgeOcrStatus');
    const dotOcr = document.getElementById('dotOcrStatus');
    const btnToggleOcr = document.getElementById('btnToggleOcr');
    if (badgeOcr && dotOcr) {
        if (loot.ocr_active) {
            badgeOcr.innerText = "DİNLİYOR";
            badgeOcr.className = "px-2 py-0.5 rounded text-[10px] font-extrabold bg-emerald-950/80 border border-emerald-800/60 text-emerald-400";
            dotOcr.className = "w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse";
            if (btnToggleOcr) btnToggleOcr.innerText = "Duraklat";
        } else {
            badgeOcr.innerText = "PASİF (GÜVENLİ)";
            badgeOcr.className = "px-2 py-0.5 rounded text-[10px] font-extrabold bg-slate-900 border border-slate-700 text-slate-400";
            dotOcr.className = "w-2.5 h-2.5 rounded-full bg-slate-500";
            if (btnToggleOcr) btnToggleOcr.innerText = "Otomatik Başlat";
        }
    }

    // ROI koordinatlarını kutucuklara yerleştir (kullanıcı odaklanmamışsa)
    if (loot.roi) {
        ['roiX', 'roiY', 'roiW', 'roiH'].forEach(id => {
            const el = document.getElementById(id);
            const key = id.replace('roi', '').toLowerCase();
            if (el && document.activeElement !== el && loot.roi[key] !== undefined) {
                el.value = loot.roi[key];
            }
        });
    }

    // Chat kamerasını güncelle
    const imgRoi = document.getElementById('imgChatRoi');
    if (imgRoi && currentTab === 'loot') {
        imgRoi.src = `/api/chat_roi?t=${Date.now()}`;
    }

    if (loot.recent_drops) {
        allLootDrops = loot.recent_drops;
        renderLootTable();
    }
}

function filterLootTable(type) {
    playUiClick();
    currentLootFilter = type;
    ['ALL', 'VALUABLE', 'COIN'].forEach(t => {
        const btn = document.getElementById(`flt-loot-${t}`);
        if (btn) {
            if (t === type) {
                btn.className = "px-2.5 py-1 rounded bg-slate-800 text-cyan-300 font-semibold transition";
            } else {
                btn.className = "px-2.5 py-1 rounded hover:bg-slate-800 text-slate-400 transition";
            }
        }
    });
    renderLootTable();
}

function renderLootTable() {
    const tbody = document.getElementById('lootTableBody');
    if (!tbody) return;
    tbody.innerHTML = '';

    const filtered = allLootDrops.filter(item => {
        if (currentLootFilter === 'ALL') return true;
        if (currentLootFilter === 'VALUABLE') return item.is_valuable;
        if (currentLootFilter === 'COIN') return item.type === 'COIN';
        return true;
    });

    if (filtered.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" class="py-6 text-center text-slate-500">Bu filtreye uygun drop bulunamadı.</td></tr>';
        return;
    }

    filtered.forEach(d => {
        const row = document.createElement('tr');
        row.className = d.is_valuable ? "bg-emerald-950/20 hover:bg-emerald-900/30 transition text-emerald-200" : "hover:bg-slate-800/40 transition text-slate-300";
        
        let typeBadge = '<span class="px-2 py-0.5 rounded text-[10px] bg-slate-800 text-slate-400 border border-slate-700">Çöp/Kutu</span>';
        if (d.type === 'COIN') {
            typeBadge = '<span class="px-2 py-0.5 rounded text-[10px] bg-amber-950 text-amber-300 border border-amber-800">🪙 Coin</span>';
        } else if (d.is_valuable) {
            typeBadge = '<span class="px-2 py-0.5 rounded text-[10px] bg-cyan-950 text-cyan-300 border border-cyan-800 animate-pulse">💎 Değerli</span>';
        }

        const valText = d.value > 0 ? `+${(d.value / 1_000_000).toFixed(2)} M` : '-';

        row.innerHTML = `
            <td class="py-2.5 px-4 text-slate-400">${escapeHtml(d.time)}</td>
            <td class="py-2.5 px-4 font-bold ${d.is_valuable ? 'text-cyan-300' : 'text-slate-200'}">${escapeHtml(d.item)}</td>
            <td class="py-2.5 px-4">${escapeHtml(d.qty)}</td>
            <td class="py-2.5 px-4 font-bold ${d.value > 0 ? 'text-emerald-400' : 'text-slate-500'}">${valText}</td>
            <td class="py-2.5 px-4">${typeBadge}</td>
        `;
        tbody.appendChild(row);
    });
}

// --- Chart.js Real-Time Financial Visuals ---
let chartDataPoints = [];
function initFinancialChart() {
    if (profitChart) return;
    const ctx = document.getElementById('profitChart');
    if (!ctx) return;

    profitChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['0m', '10m', '20m', '30m', '40m', '50m', '60m'],
            datasets: [
                {
                    label: 'Net Kâr (M Coin)',
                    data: [0, 0.4, 0.9, 1.5, 2.2, 3.1, 4.0],
                    borderColor: '#10b981',
                    backgroundColor: 'rgba(16, 185, 129, 0.1)',
                    borderWidth: 2,
                    tension: 0.35,
                    fill: true
                },
                {
                    label: 'Toplam Maliyet (Genie + Hammer)',
                    data: [0, 0.15, 0.3, 0.45, 0.6, 0.75, 0.9],
                    borderColor: '#ef4444',
                    backgroundColor: 'transparent',
                    borderWidth: 1.5,
                    borderDash: [5, 5],
                    tension: 0.2
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    labels: { color: '#94a3b8', font: { family: 'Plus Jakarta Sans', size: 11, weight: 'bold' } }
                }
            },
            scales: {
                x: {
                    grid: { color: 'rgba(51, 65, 85, 0.25)' },
                    ticks: { color: '#64748b', font: { family: 'JetBrains Mono' } }
                },
                y: {
                    grid: { color: 'rgba(51, 65, 85, 0.25)' },
                    ticks: { color: '#64748b', font: { family: 'JetBrains Mono' } }
                }
            }
        }
    });
}

function updateFinancialChart(econ) {
    if (!profitChart) return;
    // update real-time series if desired
}

// --- Engine Settings Save ---
function saveEngineSettings() {
    playUiClick();
    const triggerMode = document.querySelector('input[name="swapTriggerMode"]:checked')?.value || 'DURABILITY';
    const swapMins = parseInt(document.getElementById('cfgSwapMinutes')?.value) || 0;
    const swapSecs = parseInt(document.getElementById('cfgSwapSeconds')?.value) || 0;
    const totalSwapSec = Math.max(1, (swapMins * 60) + swapSecs);
    const vipMins = parseInt(document.getElementById('cfgVipMinutes')?.value) || 10;
    const rprKey = document.getElementById('cfgRprKey')?.value.trim() || "8";

    sendAction('update_settings', {
        swap_trigger_mode: triggerMode,
        swap_duration_sec: totalSwapSec,
        vip_duration_sec: vipMins * 60,
        rpr_key: rprKey
    });

    playSuccessChirp();
    alert('✔ Sentinel Motor Ayarları başarıyla güncellendi ve uygulandı!');
}

// --- Pro Log Terminal with Filters ---
function filterLogs(level) {
    playUiClick();
    currentLogFilter = level;
    ['ALL', 'SUCCESS', 'WARN', 'ERROR'].forEach(lvl => {
        const btn = document.getElementById(`flt-${lvl}`);
        if (lvl === level) {
            btn.className = "px-2.5 py-1 rounded bg-slate-800 text-cyan-300 font-semibold transition";
        } else {
            btn.className = "px-2.5 py-1 rounded hover:bg-slate-800 text-slate-400 transition";
        }
    });
    renderLogs();
}

function copyTextToClipboard(text) {
    if (!text) return;
    navigator.clipboard.writeText(text).then(() => {
        playTone(1100, 'sine', 0.04, 0.08);
        alert('✔ Uzaktan Erişim Linki Kopyalandı:\n' + text + '\n\nBu linki telefonunuza gönderip dilediğiniz yerden paneli izleyebilirsiniz!');
    }).catch(() => {
        prompt('Bağlantı linkinizi kopyalayabilirsiniz:', text);
    });
}

function renderLogs() {
    const container = document.getElementById('logContainer');
    const lblCount = document.getElementById('lblLogCount');
    container.innerHTML = '';

    const filtered = allLogs.filter(log => {
        if (currentLogFilter === 'ALL') return true;
        return log.level === currentLogFilter;
    });

    lblCount.innerText = `${filtered.length} Log`;

    if (filtered.length === 0) {
        container.innerHTML = '<div class="text-slate-600">[--:--:--] Bu filtreye uygun log bulunamadı.</div>';
        return;
    }

    filtered.forEach(log => {
        const row = document.createElement('div');
        row.className = getLogLevelClass(log.level) + " select-text py-0.5";
        
        const urlMatch = log.message.match(/https?:\/\/[^\s"'<>]+/);
        if (urlMatch) {
            const url = urlMatch[0];
            const cleanUrl = url.replace(/[.,;)]+$/, '');
            const safeCleanUrl = escapeHtml(cleanUrl);
            const linkHtml = `<a href="${safeCleanUrl}" target="_blank" rel="noopener noreferrer" class="underline text-cyan-400 font-bold hover:text-cyan-300 ml-1 mr-1">${safeCleanUrl}</a>` +
                             `<button onclick="copyTextToClipboard('${safeCleanUrl}')" class="px-2 py-0.5 text-[10px] bg-cyan-950 border border-cyan-700 text-cyan-300 rounded hover:bg-cyan-800 transition mr-1 cursor-pointer">📋 Kopyala</button>` +
                             `<button onclick="window.open('${safeCleanUrl}', '_blank')" class="px-2 py-0.5 text-[10px] bg-emerald-950 border border-emerald-700 text-emerald-300 rounded hover:bg-emerald-800 transition cursor-pointer">↗ Aç</button>`;
            const escapedMsg = escapeHtml(log.message);
            row.innerHTML = `<span class="opacity-75">[${escapeHtml(log.time)}]</span> ` + escapedMsg.replace(safeCleanUrl, linkHtml);
        } else {
            row.innerText = `[${log.time}] ${log.message}`;
        }
        container.appendChild(row);
    });
}

function getLogLevelClass(level) {
    switch (level) {
        case 'WARN': return 'text-amber-400 font-semibold';
        case 'ERROR': return 'text-rose-400 font-bold';
        case 'SUCCESS': return 'text-emerald-400 font-semibold';
        default: return 'text-slate-300';
    }
}

function appendLog(log) {
    allLogs.unshift(log);
    renderLogs();
}

function clearLogs() {
    playUiClick();
    allLogs = [];
    renderLogs();
}

function sendAction(actionName, params = {}) {
    playUiClick();
    if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ action: actionName, params: params }));
    } else {
        alert('WebSocket bağlantısı kesildi. Lütfen sunucunun açık olduğundan emin olun.');
    }
}

function toggleMaster() {
    playUiClick();
    sendAction('toggle_master');
}

function stopMaster() {
    playUiClick();
    if (confirm("Master otomasyon durdurulsun ve tüm süreç (silah rotasyonu, sayaçlar) Çift 1'e tamamen sıfırlansın mı?")) {
        sendAction('stop_master');
    }
}

function confirmShutdown() {
    playAlertChirp();
    if (confirm("Sentinel botunu, Cloudflare tünelini ve arka planda çalışan tüm servisleri (AHK, Sunucu) tamamen kapatmak istiyor musunuz?")) {
        try {
            authFetch('/api/system/shutdown', { method: 'POST' }).catch(() => {});
        } catch (e) {}
        document.body.innerHTML = `
            <div style="height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;background:#060913;color:#94a3b8;font-family:'Segoe UI',sans-serif;text-align:center;padding:24px;">
                <div style="width:72px;height:72px;border-radius:20px;background:#ef4444;display:flex;align-items:center;justify-content:center;color:#fff;font-size:36px;margin-bottom:24px;box-shadow:0 0 30px rgba(239,68,68,0.4);">⏻</div>
                <h1 style="color:#fff;font-size:24px;font-weight:800;letter-spacing:1px;margin-bottom:12px;">SENTINEL BAŞARIYLA KAPATILDI</h1>
                <p style="font-size:14px;color:#94a3b8;max-width:440px;line-height:1.6;margin-bottom:24px;">Tüm arka plan servisleri (AutoHotkey, Cloudflare Tünel ve Python Sunucusu) tamamen sonlandırıldı. Bu tarayıcı sekmesini güvenle kapatabilirsiniz.</p>
                <div style="font-size:12px;color:#64748b;font-family:monospace;background:#0b0f19;padding:8px 16px;border-radius:8px;border:1px solid #1e293b;">DURUM: OFFLINE</div>
            </div>
        `;
    }
}

// --- Telegram Modal & API Entegrasyonu ---
function openTelegramModal() {
    playUiClick();
    document.getElementById('tgModal').classList.remove('hidden');
    loadTelegramConfig();
}

function closeTelegramModal() {
    playUiClick();
    document.getElementById('tgModal').classList.add('hidden');
}

async function loadTelegramConfig() {
    try {
        const res = await authFetch('/api/telegram/config');
        const data = await res.json();
        document.getElementById('tgTokenInput').value = data.bot_token || '';
        document.getElementById('tgChatIdInput').value = data.chat_id || '';
        
        const tgBtn = document.getElementById('btnTelegram');
        const tgText = document.getElementById('tgStatusText');
        if (data.enabled) {
            tgBtn.className = "flex items-center gap-2 px-3 py-1.5 rounded-xl border text-xs font-semibold bg-emerald-950/40 border-emerald-800/60 text-emerald-400 transition";
            tgText.innerText = "Telegram Aktif";
        } else {
            tgBtn.className = "flex items-center gap-2 px-3 py-1.5 rounded-xl border text-xs font-semibold bg-slate-800/60 hover:bg-slate-700/60 border-slate-700/60 text-slate-300 transition";
            tgText.innerText = "Telegram Kur";
        }
    } catch (e) {
        console.error('Telegram ayarları yüklenemedi:', e);
    }
}

async function saveTelegramSettings() {
    const token = document.getElementById('tgTokenInput').value.trim();
    const chatId = document.getElementById('tgChatIdInput').value.trim();
    if (!token || !chatId) {
        alert('Lütfen Bot Token ve Chat ID alanlarını doldurun.');
        return;
    }

    try {
        const res = await authFetch('/api/telegram/config', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ bot_token: token, chat_id: chatId })
        });
        const data = await res.json();
        if (data.status === 'ok') {
            playSuccessChirp();
            alert('✔ Telegram ayarları kaydedildi ve test mesajı gönderildi!');
            closeTelegramModal();
            loadTelegramConfig();
        }
    } catch (e) {
        alert('Ayarlar kaydedilirken hata oluştu: ' + e);
    }
}

function triggerTelegramSnapshot() {
    playUiClick();
    sendAction('telegram_snapshot');
}

function saveChatRoi() {
    playUiClick();
    const x = parseInt(document.getElementById('roiX').value) || 980;
    const y = parseInt(document.getElementById('roiY').value) || 590;
    const w = parseInt(document.getElementById('roiW').value) || 340;
    const h = parseInt(document.getElementById('roiH').value) || 170;
    sendAction('update_loot_roi', { x, y, w, h });
    const imgRoi = document.getElementById('imgChatRoi');
    if (imgRoi) {
        setTimeout(() => { imgRoi.src = `/api/chat_roi?t=${Date.now()}`; }, 200);
    }
}

// ==============================================================================
// GÜVENLİK KAPISI & ÜYELİK / LİSANS DOĞRULAMA MOTORU
// ==============================================================================
let cachedHwid = "";

function switchAuthView(viewName) {
    playUiClick();
    const vLogin = document.getElementById('viewLogin');
    const vReg = document.getElementById('viewRegister');
    const vExp = document.getElementById('viewExpired');
    const tabLog = document.getElementById('btnTabLogin');
    const tabReg = document.getElementById('btnTabRegister');
    const errEl = document.getElementById('authErrorMsg');
    if (errEl) errEl.classList.add('hidden');

    if (viewName === 'register') {
        if (vLogin) vLogin.classList.add('hidden');
        if (vExp) vExp.classList.add('hidden');
        if (vReg) vReg.classList.remove('hidden');
        if (tabLog) { tabLog.className = "py-2 rounded-lg text-slate-400 hover:text-white transition"; }
        if (tabReg) { tabReg.className = "py-2 rounded-lg bg-emerald-600 text-white transition"; }
    } else if (viewName === 'expired') {
        if (vLogin) vLogin.classList.add('hidden');
        if (vReg) vReg.classList.add('hidden');
        if (vExp) vExp.classList.remove('hidden');
        const tabsCont = document.getElementById('authTabsContainer');
        if (tabsCont) tabsCont.classList.add('hidden');
    } else {
        if (vReg) vReg.classList.add('hidden');
        if (vExp) vExp.classList.add('hidden');
        if (vLogin) vLogin.classList.remove('hidden');
        if (tabLog) { tabLog.className = "py-2 rounded-lg bg-cyan-600 text-white transition"; }
        if (tabReg) { tabReg.className = "py-2 rounded-lg text-slate-400 hover:text-white transition"; }
        const tabsCont = document.getElementById('authTabsContainer');
        if (tabsCont) tabsCont.classList.remove('hidden');
    }
}

async function checkAuthStatus() {
    const token = sessionStorage.getItem('sentinel_auth_token');
    const authModal = document.getElementById('authModal');
    
    try {
        const res = await fetch('/api/auth/status');
        const data = await res.json();
        
        if (data.hwid) {
            cachedHwid = data.hwid;
            const authHwid = document.getElementById('authHwidLabel');
            if (authHwid) authHwid.innerText = cachedHwid;
            const modalHwid = document.getElementById('modalHwidText');
            if (modalHwid) modalHwid.innerText = cachedHwid;
        }
        if (data.license) updateLicenseUI(data.license);

        // Henüz üyelik kaydı yoksa veya lisans hiç girilmemişse doğrudan Kayıt & Lisans Gir sekmesini aç
        if (!data.user_registered || !data.is_valid) {
            if (authModal) authModal.classList.remove('hidden');
            if (!data.user_registered) {
                switchAuthView('register');
            } else if (!data.is_valid) {
                switchAuthView('expired');
            }
            return;
        }

        // Eğer kayıtlı ve lisans geçerliyse token kontrolü yap
        if (!data.auth_enabled || token) {
            if (authModal) authModal.classList.add('hidden');
        } else {
            if (authModal) authModal.classList.remove('hidden');
            switchAuthView('login');
        }
    } catch (e) {
        if (!token && authModal) authModal.classList.remove('hidden');
    }
}

function lockScreen() {
    playUiClick();
    sessionStorage.removeItem('sentinel_auth_token');
    const authModal = document.getElementById('authModal');
    if (authModal) authModal.classList.remove('hidden');
    switchAuthView('login');
}

function copyAuthHwid() {
    if (!cachedHwid) return;
    navigator.clipboard.writeText(cachedHwid).then(() => {
        playTone(1100, 'sine', 0.04, 0.08);
        alert(`✔ HWID Kodu Panoya Kopyalandı:\n${cachedHwid}\n\nBu kodu yöneticinize ileterek lisans anahtarınızı alabilirsiniz.`);
    });
}

async function submitUserLogin() {
    const uInp = document.getElementById('loginUsername');
    const pInp = document.getElementById('loginPassword');
    const errEl = document.getElementById('authErrorMsg');
    
    const username = uInp ? uInp.value.trim() : "";
    const password = pInp ? pInp.value.trim() : "";
    
    if (!username || !password) {
        if (errEl) {
            errEl.innerText = "Lütfen kullanıcı adı ve şifrenizi giriniz!";
            errEl.className = "text-xs text-center font-bold text-rose-400 min-h-[1.25rem]";
            errEl.classList.remove('hidden');
        }
        return;
    }
    
    try {
        const res = await fetch('/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });
        const data = await res.json();
        
        if (res.ok && data.status === 'ok') {
            playSuccessChirp();
            sessionStorage.setItem('sentinel_auth_token', data.token);
            if (errEl) errEl.classList.add('hidden');
            const authModal = document.getElementById('authModal');
            if (authModal) authModal.classList.add('hidden');
            if (ws) { try { ws.close(); } catch(e){} }
            connectWS();
        } else if (res.status === 403 || data.status === 'license_expired') {
            playAlertChirp();
            switchAuthView('expired');
        } else {
            playAlertChirp();
            if (errEl) {
                errEl.innerText = data.message || "Hatalı Giriş Bilgileri!";
                errEl.className = "text-xs text-center font-bold text-rose-400 min-h-[1.25rem]";
                errEl.classList.remove('hidden');
            }
        }
    } catch (e) {
        if (errEl) {
            errEl.innerText = "Sunucu bağlantı hatası: " + e;
            errEl.className = "text-xs text-center font-bold text-rose-400 min-h-[1.25rem]";
            errEl.classList.remove('hidden');
        }
    }
}

async function submitUserRegister() {
    const uInp = document.getElementById('regUsername');
    const pInp = document.getElementById('regPassword');
    const kInp = document.getElementById('regLicenseKey');
    const errEl = document.getElementById('authErrorMsg');
    
    const username = uInp ? uInp.value.trim() : "";
    const password = pInp ? pInp.value.trim() : "";
    const license_key = kInp ? kInp.value.trim().toUpperCase() : "";
    
    if (!username || !password || !license_key) {
        if (errEl) {
            errEl.innerText = "Lütfen tüm alanları (Kullanıcı Adı, Şifre, Lisans) doldurun!";
            errEl.className = "text-xs text-center font-bold text-rose-400 min-h-[1.25rem]";
            errEl.classList.remove('hidden');
        }
        return;
    }
    
    try {
        const res = await fetch('/api/auth/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password, license_key })
        });
        const data = await res.json();
        
        if (res.ok && data.status === 'ok') {
            playSuccessChirp();
            sessionStorage.setItem('sentinel_auth_token', data.token);
            if (errEl) {
                errEl.innerText = data.message;
                errEl.className = "text-xs text-center font-bold text-emerald-400 min-h-[1.25rem]";
                errEl.classList.remove('hidden');
            }
            if (ws) { try { ws.close(); } catch(e){} }
            connectWS();
            setTimeout(() => {
                const authModal = document.getElementById('authModal');
                if (authModal) authModal.classList.add('hidden');
            }, 1200);
        } else {
            playAlertChirp();
            if (errEl) {
                errEl.innerText = data.message || "Kayıt işlemi başarısız!";
                errEl.className = "text-xs text-center font-bold text-rose-400 min-h-[1.25rem]";
                errEl.classList.remove('hidden');
            }
        }
    } catch (e) {
        if (errEl) {
            errEl.innerText = "Hata: " + e;
            errEl.className = "text-xs text-center font-bold text-rose-400 min-h-[1.25rem]";
            errEl.classList.remove('hidden');
        }
    }
}

async function submitRenewLicense() {
    const kInp = document.getElementById('renewLicenseKey');
    const errEl = document.getElementById('authErrorMsg');
    const key = kInp ? kInp.value.trim().toUpperCase() : "";
    
    if (!key) {
        if (errEl) {
            errEl.innerText = "Lütfen yeni lisans kodunuzu giriniz!";
            errEl.className = "text-xs text-center font-bold text-rose-400 min-h-[1.25rem]";
            errEl.classList.remove('hidden');
        }
        return;
    }
    
    try {
        const res = await authFetch('/api/license/activate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ key })
        });
        const data = await res.json();
        
        if (res.ok && data.status === 'ok') {
            playSuccessChirp();
            if (errEl) {
                errEl.innerText = data.message;
                errEl.className = "text-xs text-center font-bold text-emerald-400 min-h-[1.25rem]";
                errEl.classList.remove('hidden');
            }
            setTimeout(() => {
                switchAuthView('login');
                if (errEl) errEl.classList.add('hidden');
            }, 1500);
        } else {
            playAlertChirp();
            if (errEl) {
                errEl.innerText = data.message || "Geçersiz Lisans!";
                errEl.className = "text-xs text-center font-bold text-rose-400 min-h-[1.25rem]";
                errEl.classList.remove('hidden');
            }
        }
    } catch (e) {
        if (errEl) {
            errEl.innerText = "Hata: " + e;
            errEl.className = "text-xs text-center font-bold text-rose-400 min-h-[1.25rem]";
            errEl.classList.remove('hidden');
        }
    }
}


// ==============================================================================
// LİSANS VE GÜVENLİK YÖNETİMİ
// ==============================================================================
function updateLicenseUI(lic) {
    if (!lic) return;
    cachedHwid = lic.hwid || cachedHwid;
    const authHwid = document.getElementById('authHwidLabel');
    if (authHwid) authHwid.innerText = cachedHwid;
    
    const modalHwid = document.getElementById('modalHwidText');
    if (modalHwid) modalHwid.innerText = cachedHwid;
    
    const daysEl = document.getElementById('modalDaysRemaining');
    if (daysEl) daysEl.innerText = `${lic.days_remaining} Gün`;
    
    const expEl = document.getElementById('modalExpiryDate');
    if (expEl) expEl.innerText = lic.expiry_date || "-";
    
    const badgeBtn = document.getElementById('btnLicenseBadge');
    const badgeTxt = document.getElementById('lblLicenseDays');
    
    if (lic.is_valid) {
        if (badgeBtn) badgeBtn.className = "flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold bg-emerald-950/40 border-emerald-700/50 text-emerald-400 hover:bg-emerald-900/40 transition";
        if (badgeTxt) badgeTxt.innerText = `Lisans: ${lic.days_remaining} Gün`;
    } else {
        if (badgeBtn) badgeBtn.className = "flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold bg-rose-950/60 border-rose-700/60 text-rose-400 hover:bg-rose-900/40 transition animate-pulse";
        if (badgeTxt) badgeTxt.innerText = "Lisans Hatası!";
    }
}

function openLicenseModal() {
    playUiClick();
    const modal = document.getElementById('licenseModal');
    if (modal) modal.classList.remove('hidden');
}

function closeLicenseModal() {
    playUiClick();
    const modal = document.getElementById('licenseModal');
    if (modal) modal.classList.add('hidden');
}

function copyHwid() {
    if (!cachedHwid) return;
    navigator.clipboard.writeText(cachedHwid).then(() => {
        playTone(1100, 'sine', 0.04, 0.08);
        alert(`✔ HWID Kodu Kopyalandı:\n${cachedHwid}\n\nYöneticinize bu kodu ileterek yeni lisans anahtarı talep edebilirsiniz.`);
    });
}

async function submitNewLicense() {
    const keyInput = document.getElementById('licenseKeyInput');
    const alertEl = document.getElementById('modalLicAlert');
    const key = keyInput ? keyInput.value.trim() : "";
    
    if (!key) {
        if (alertEl) {
            alertEl.innerText = "Lütfen lisans anahtarını girin!";
            alertEl.className = "text-xs font-semibold text-rose-400";
            alertEl.classList.remove('hidden');
        }
        return;
    }
    
    try {
        const res = await authFetch('/api/license/activate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ key: key })
        });
        const data = await res.json();
        if (res.ok && data.status === 'ok') {
            playSuccessChirp();
            if (alertEl) {
                alertEl.innerText = data.message;
                alertEl.className = "text-xs font-semibold text-emerald-400";
                alertEl.classList.remove('hidden');
            }
            if (data.license) updateLicenseUI(data.license);
            setTimeout(() => {
                closeLicenseModal();
                if (alertEl) alertEl.classList.add('hidden');
            }, 1800);
        } else {
            playAlertChirp();
            if (alertEl) {
                alertEl.innerText = data.message || "Geçersiz Lisans!";
                alertEl.className = "text-xs font-semibold text-rose-400";
                alertEl.classList.remove('hidden');
            }
        }
    } catch (e) {
        if (alertEl) {
            alertEl.innerText = "Hata: " + e;
            alertEl.className = "text-xs font-semibold text-rose-400";
            alertEl.classList.remove('hidden');
        }
    }
}

// --- Mandatory Auto-Updater Controller ---
let currentUpdateDownloadUrl = "";

function handleUpdateTelemetry(upd) {
    if (!upd) return;
    if (upd.available && upd.mandatory) {
        showMandatoryUpdateModal(upd);
    }
}

async function checkSystemUpdate() {
    try {
        const res = await authFetch('/api/system/version');
        if (res.ok) {
            const data = await res.json();
            if (data.update_available && data.mandatory) {
                showMandatoryUpdateModal(data);
            }
        }
    } catch (e) {
        console.error('[Updater] Version check error:', e);
    }
}

function showMandatoryUpdateModal(info) {
    const modal = document.getElementById('mandatoryUpdateModal');
    if (!modal) return;

    currentUpdateDownloadUrl = info.download_url || "";
    
    const badge = document.getElementById('updateModalNewVerBadge');
    if (badge) badge.innerText = `v${info.latest_version || '3.2.0'}`;
    
    const curVerEl = document.getElementById('updateModalCurrentVer');
    if (curVerEl) curVerEl.innerText = `v${info.current_version || '3.1.0'}`;
    
    const tgtVerEl = document.getElementById('updateModalTargetVer');
    if (tgtVerEl) tgtVerEl.innerText = `v${info.latest_version || '3.2.0'}`;

    const clEl = document.getElementById('updateModalChangelog');
    if (clEl) {
        clEl.innerHTML = '';
        const list = info.changelog && info.changelog.length > 0 ? info.changelog : [
            "Akıllı Slot Koruma Matrisi devreye alındı.",
            "VIP aktarım ve Anvil kilitli slot koruma kalkanı eklendi.",
            "Zorunlu otomatik güncelleme sistemi entegre edildi."
        ];
        list.forEach(item => {
            const row = document.createElement('div');
            row.className = "flex items-start gap-2";
            row.innerHTML = `<span class="text-amber-400 font-bold">✔</span> <span>${item}</span>`;
            clEl.appendChild(row);
        });
    }

    modal.classList.remove('hidden');
}

async function applyMandatoryUpdate() {
    playUiClick();
    const btn = document.getElementById('btnApplyUpdate');
    const pBox = document.getElementById('updateModalProgressBox');
    const pText = document.getElementById('updateModalProgressText');

    if (btn) {
        btn.disabled = true;
        btn.classList.add('opacity-50', 'cursor-not-allowed');
    }
    if (pBox) pBox.classList.remove('hidden');
    if (pText) pText.innerText = "Güncelleme paketi indiriliyor ve dosyalar yenileniyor...";

    try {
        const resp = await authFetch('/api/system/apply_update', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ download_url: currentUpdateDownloadUrl })
        });
        const resData = await resp.json();

        if (resp.ok && resData.status === 'ok') {
            playSuccessChirp();
            if (pText) pText.innerText = `✔ ${resData.message} Sayfa 2 saniye içinde yenileniyor...`;
            if (pBox) {
                pBox.className = "p-3 rounded-xl bg-emerald-950/60 border border-emerald-700 text-xs text-emerald-200 flex items-center gap-3";
            }
            setTimeout(() => {
                window.location.reload(true);
            }, 2000);
        } else {
            playAlertChirp();
            if (pText) pText.innerText = `✖ Hata: ${resData.message || 'Güncelleme uygulanamadı.'}`;
            if (pBox) {
                pBox.className = "p-3 rounded-xl bg-rose-950/60 border border-rose-700 text-xs text-rose-200 flex items-center gap-3";
            }
            if (btn) {
                btn.disabled = false;
                btn.classList.remove('opacity-50', 'cursor-not-allowed');
            }
        }
    } catch (e) {
        playAlertChirp();
        if (pText) pText.innerText = `✖ Ağ Hatası: ${e}`;
        if (pBox) {
            pBox.className = "p-3 rounded-xl bg-rose-950/60 border border-rose-700 text-xs text-rose-200 flex items-center gap-3";
        }
        if (btn) {
            btn.disabled = false;
            btn.classList.remove('opacity-50', 'cursor-not-allowed');
        }
    }
}

// Lifecycle Init
window.addEventListener('DOMContentLoaded', () => {
    checkAuthStatus();
    checkSystemUpdate();
    connectWS();
    startStreamLoop();
    buildSlotMatrices();
    buildAnvilSlotMatrix();
    attachAutoSaveListeners();

    const elAnvStart = document.getElementById('cfgAnvilStart');
    const elAnvEnd = document.getElementById('cfgAnvilEnd');
    if (elAnvStart) elAnvStart.addEventListener('input', () => buildAnvilSlotMatrix());
    if (elAnvEnd) elAnvEnd.addEventListener('input', () => buildAnvilSlotMatrix());
});
